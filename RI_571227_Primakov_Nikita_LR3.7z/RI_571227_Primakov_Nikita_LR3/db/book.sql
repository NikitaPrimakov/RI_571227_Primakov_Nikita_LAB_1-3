create table book
(
	name text,
	id integer not null
	constraint book_pk
	primary key
);
