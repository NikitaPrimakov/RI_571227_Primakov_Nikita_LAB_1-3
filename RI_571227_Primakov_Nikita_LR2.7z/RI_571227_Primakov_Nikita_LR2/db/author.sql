create table author
(
	name text,
	id integer not null
	constraint author_pkey
	primary key
);