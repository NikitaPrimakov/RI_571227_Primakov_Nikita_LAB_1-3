create table if not exists users
(
	name text,
	pass text
);
